require([
    "jquery"
],function($) {
	
	$(document).ready(function(){
$('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    responsiveClass:true,
    items:1
})
		

	});
})